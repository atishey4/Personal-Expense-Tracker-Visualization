import pandas as pd

from src.analyze import fetch_frame, kpis
from src.budget import check_budget
from src.categorize import run as categorize_transactions
from src.ingest import upsert_transactions
from src.models import PROJECT_ROOT, init_db
from src.plots import (
    budget_vs_actual,
    category_bar,
    daily_trend,
    monthly_trend,
    payment_pie,
)
from src.report import export_month


SAMPLE_CSV = PROJECT_ROOT / "data" / "expenses_sample.csv"


def load_sample_transactions():
    sample = pd.read_csv(SAMPLE_CSV)
    normalized = pd.DataFrame(
        {
            "tx_date": pd.to_datetime(sample["Date"], errors="coerce").dt.strftime(
                "%Y-%m-%d"
            ),
            "description": sample["Description"].astype("string").str.strip(),
            "amount": pd.to_numeric(sample["Amount"], errors="coerce"),
            "account": sample["Account"].astype("string").str.strip(),
            "raw_source": str(SAMPLE_CSV),
        }
    )
    return normalized.dropna(
        subset=["tx_date", "description", "amount", "account", "raw_source"]
    ).reset_index(drop=True)


def print_kpi_summary(df):
    summary = kpis(df)

    print("\nKPI Summary")
    print(f"Total Spend: INR {summary['total_spend']:,.2f}")
    print(f"Income: INR {summary['income']:,.2f}")
    print(f"Savings: INR {summary['savings']:,.2f}")
    print("\nTop 3 Spending Categories")

    top_categories = summary["top_5_categories"].head(3)
    if top_categories.empty:
        print("No expense categories found.")
        return

    for index, row in top_categories.iterrows():
        print(f"{index + 1}. {row['category']}: INR {row['spend']:,.2f}")


def main():
    init_db()

    sample_transactions = load_sample_transactions()
    inserted = upsert_transactions(sample_transactions)
    categorized = categorize_transactions()

    df = fetch_frame()
    sample_months = sorted(
        pd.to_datetime(sample_transactions["tx_date"]).dt.to_period("M").astype(str).unique()
    )
    report_month = sample_months[-1]

    budget_df = check_budget(report_month)
    chart_paths = [
        monthly_trend(df),
        category_bar(df, report_month),
        payment_pie(df, report_month),
        daily_trend(df),
        budget_vs_actual(budget_df),
    ]
    report_path = export_month(report_month)

    print("Personal Expense Tracker Visualization")
    print(f"Sample rows processed: {len(sample_transactions)}")
    print(f"New transactions inserted: {inserted}")
    print(f"Transactions categorized: {categorized}")
    print(f"Report month: {report_month}")
    print("\nCharts generated:")
    for path in chart_paths:
        print(f"- {path}")
    print(f"\nExcel report: {report_path}")
    print_kpi_summary(df)


if __name__ == "__main__":
    main()
