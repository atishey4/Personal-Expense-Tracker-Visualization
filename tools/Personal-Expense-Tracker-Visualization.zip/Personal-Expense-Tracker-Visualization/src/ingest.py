from pathlib import Path
import sqlite3

import pandas as pd

from src.models import DB_PATH, init_db


def read_bank_csv(path, account, date_col, desc_col, amt_col):
    """Load a bank CSV and normalize it for the transactions table."""
    path = Path(path)
    df = pd.read_csv(path)

    required_cols = [date_col, desc_col, amt_col]
    missing_cols = [col for col in required_cols if col not in df.columns]
    if missing_cols:
        raise ValueError(f"Missing required columns: {', '.join(missing_cols)}")

    normalized = pd.DataFrame(
        {
            "tx_date": pd.to_datetime(df[date_col], errors="coerce"),
            "description": df[desc_col].astype("string").str.strip(),
            "amount": pd.to_numeric(
                df[amt_col].astype("string").str.replace(",", "", regex=False),
                errors="coerce",
            ),
            "account": account,
            "raw_source": str(path),
        }
    )
    normalized["tx_date"] = normalized["tx_date"].dt.strftime("%Y-%m-%d")

    return normalized.dropna(
        subset=["tx_date", "description", "amount", "account", "raw_source"]
    ).reset_index(drop=True)


def upsert_transactions(df, db_path=DB_PATH):
    """Insert normalized transactions into SQLite, ignoring duplicates."""
    init_db(db_path)

    records = df[
        ["tx_date", "description", "amount", "account", "raw_source"]
    ].to_records(index=False)

    with sqlite3.connect(db_path) as conn:
        conn.execute("PRAGMA foreign_keys=ON")
        before = conn.total_changes
        conn.executemany(
            """
            INSERT OR IGNORE INTO transactions (
                tx_date, description, amount, account, raw_source
            )
            VALUES (?, ?, ?, ?, ?)
            """,
            records,
        )
        return conn.total_changes - before
