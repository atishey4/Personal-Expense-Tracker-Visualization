import re
import sqlite3

from src.models import DB_PATH, init_db


RULES = {
    "Food & Dining": [
        r"\bswiggy\b",
        r"\bzomato\b",
        r"\bdominos?\b",
        r"\bpizza hut\b",
        r"\brestaurant\b",
        r"\bcafe\b",
        r"\bcoffee\b",
        r"\blunch\b",
        r"\bdinner\b",
        r"\bbrunch\b",
        r"\bfood\b",
    ],
    "Shopping": [
        r"\bamazon\b",
        r"\bflipkart\b",
        r"\bmyntra\b",
        r"\bnykaa\b",
        r"\bmeesho\b",
        r"\bshopping\b",
        r"\bclothing\b",
        r"\belectronics?\b",
        r"\bgift\b",
    ],
    "Transport": [
        r"\buber\b",
        r"\bola\b",
        r"\bmetro\b",
        r"\brapido\b",
        r"\bmakemytrip\b",
        r"\birctc\b",
        r"\bcab\b",
        r"\bauto\b",
        r"\bfuel\b",
        r"\bparking\b",
    ],
    "Groceries": [
        r"\bbigbasket\b",
        r"\blinkit\b",
        r"\bzepto\b",
        r"\bgrofers\b",
        r"\bdmart\b",
        r"\breliance fresh\b",
        r"\bgrocer(y|ies)\b",
        r"\bsupermarket\b",
        r"\bvegetables?\b",
        r"\bdairy\b",
        r"\bfruit\b",
        r"\bstaples?\b",
    ],
    "Bills & Utilities": [
        r"\bbescom\b",
        r"\btata power\b",
        r"\badani electricity\b",
        r"\bairtel\b",
        r"\bjio\b",
        r"\bvi\b",
        r"\bvodafone\b",
        r"\bact fibernet\b",
        r"\belectricity\b",
        r"\binternet\b",
        r"\bmobile recharge\b",
        r"\bwater bill\b",
        r"\bgas cylinder\b",
        r"\butilit(y|ies)\b",
    ],
    "Entertainment": [
        r"\bnetflix\b",
        r"\bspotify\b",
        r"\bprime video\b",
        r"\bhotstar\b",
        r"\bbookmyshow\b",
        r"\bpvr\b",
        r"\binox\b",
        r"\bmovie\b",
        r"\bstreaming\b",
        r"\bconcert\b",
        r"\bgaming\b",
        r"\bouting\b",
    ],
    "Income": [
        r"\bsalary\b",
        r"\brefund\b",
        r"\breimbursement\b",
        r"\bfreelance\b",
        r"\binterest credit\b",
        r"\bcashback\b",
        r"\bincome\b",
    ],
}


def classify(description):
    """Return the first matching category for a transaction description."""
    if not description:
        return None

    for category, patterns in RULES.items():
        if any(re.search(pattern, description, re.IGNORECASE) for pattern in patterns):
            return category

    return None


def run(db_path=DB_PATH):
    """Categorize all uncategorized transactions in SQLite."""
    init_db(db_path)

    with sqlite3.connect(db_path) as conn:
        conn.execute("PRAGMA foreign_keys=ON")

        for category in RULES:
            conn.execute(
                "INSERT OR IGNORE INTO categories (name) VALUES (?)",
                (category,),
            )

        category_ids = {
            name: category_id
            for category_id, name in conn.execute("SELECT id, name FROM categories")
        }

        updates = []
        for tx_id, description in conn.execute(
            """
            SELECT id, description
            FROM transactions
            WHERE category_id IS NULL
            """
        ):
            category = classify(description)
            if category:
                updates.append((category_ids[category], tx_id))

        conn.executemany(
            "UPDATE transactions SET category_id = ? WHERE id = ?",
            updates,
        )
        return len(updates)


if __name__ == "__main__":
    print(f"Categorized {run()} transactions")
