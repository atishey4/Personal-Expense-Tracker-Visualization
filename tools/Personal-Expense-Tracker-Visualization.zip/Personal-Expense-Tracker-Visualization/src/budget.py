import sqlite3

import pandas as pd

from src.models import DB_PATH, init_db


def set_budget(month, category, limit, db_path=DB_PATH):
    """Insert a monthly category budget."""
    init_db(db_path)

    with sqlite3.connect(db_path) as conn:
        conn.execute("PRAGMA foreign_keys=ON")
        cursor = conn.execute(
            """
            INSERT INTO budgets (month, category_name, limit_amount)
            VALUES (?, ?, ?)
            """,
            (month, category, float(limit)),
        )
        return cursor.lastrowid


def check_budget(month, db_path=DB_PATH):
    """Compare actual category spend against budgets for a month."""
    init_db(db_path)

    with sqlite3.connect(db_path) as conn:
        budgets = pd.read_sql_query(
            """
            SELECT category_name AS category, limit_amount
            FROM budgets
            WHERE month = ?
            """,
            conn,
            params=(month,),
        )

        actuals = pd.read_sql_query(
            """
            SELECT
                COALESCE(c.name, 'Uncategorized') AS category,
                SUM(ABS(t.amount)) AS actual_spend
            FROM transactions t
            LEFT JOIN categories c ON c.id = t.category_id
            WHERE strftime('%Y-%m', t.tx_date) = ?
              AND t.amount < 0
            GROUP BY COALESCE(c.name, 'Uncategorized')
            """,
            conn,
            params=(month,),
        )

    result = budgets.merge(actuals, on="category", how="left")
    result["actual_spend"] = result["actual_spend"].fillna(0.0)
    result["over_by"] = (result["actual_spend"] - result["limit_amount"]).clip(lower=0)
    result["over_budget"] = result["over_by"] > 0

    return result[
        ["category", "limit_amount", "actual_spend", "over_by", "over_budget"]
    ].sort_values(["over_budget", "over_by", "category"], ascending=[False, False, True])
