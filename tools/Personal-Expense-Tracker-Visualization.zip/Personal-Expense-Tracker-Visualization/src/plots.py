from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

from src.models import PROJECT_ROOT


OUTPUT_DIR = PROJECT_ROOT / "outputs"


def _save_chart(fig, filename):
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_path = OUTPUT_DIR / filename
    fig.tight_layout()
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    return output_path


def _expense_frame(df):
    expenses = df[df["amount"] < 0].copy()
    expenses["spend"] = expenses["amount"].abs()
    if "tx_date" in expenses.columns:
        expenses["tx_date"] = pd.to_datetime(expenses["tx_date"])
    if "month" not in expenses.columns and "tx_date" in expenses.columns:
        expenses["month"] = expenses["tx_date"].dt.to_period("M").astype(str)
    return expenses


def monthly_trend(df):
    """Save a line chart of monthly spend."""
    expenses = _expense_frame(df)
    monthly = (
        expenses.groupby("month", as_index=False)["spend"].sum().sort_values("month")
    )

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.plot(monthly["month"], monthly["spend"], marker="o", linewidth=2)
    ax.set_title("Monthly Spend Trend")
    ax.set_xlabel("Month")
    ax.set_ylabel("Spend")
    ax.grid(True, alpha=0.3)
    ax.tick_params(axis="x", rotation=45)

    return _save_chart(fig, "monthly_trend.png")


def category_bar(df, month):
    """Save a horizontal bar chart of category-wise spend for a month."""
    expenses = _expense_frame(df)
    category_spend = (
        expenses[expenses["month"] == month]
        .groupby("category", as_index=False)["spend"]
        .sum()
        .sort_values("spend")
    )

    fig, ax = plt.subplots(figsize=(9, 5))
    ax.barh(category_spend["category"], category_spend["spend"], color="#4c78a8")
    ax.set_title(f"Category Spend - {month}")
    ax.set_xlabel("Spend")
    ax.set_ylabel("Category")
    ax.grid(axis="x", alpha=0.3)

    return _save_chart(fig, f"category_bar_{month}.png")


def payment_pie(df, month):
    """Save a pie chart of spend by payment account for a month."""
    expenses = _expense_frame(df)
    payment_spend = (
        expenses[expenses["month"] == month]
        .groupby("account", as_index=False)["spend"]
        .sum()
        .sort_values("spend", ascending=False)
    )

    fig, ax = plt.subplots(figsize=(7, 7))
    ax.pie(
        payment_spend["spend"],
        labels=payment_spend["account"],
        autopct="%1.1f%%",
        startangle=90,
    )
    ax.set_title(f"Payment Spend Split - {month}")
    ax.axis("equal")

    return _save_chart(fig, f"payment_pie_{month}.png")


def daily_trend(df):
    """Save an area chart of daily cumulative spend."""
    expenses = _expense_frame(df)
    daily = (
        expenses.groupby("tx_date", as_index=False)["spend"]
        .sum()
        .sort_values("tx_date")
    )
    daily["cumulative_spend"] = daily["spend"].cumsum()

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.fill_between(
        daily["tx_date"],
        daily["cumulative_spend"],
        color="#72b7b2",
        alpha=0.45,
    )
    ax.plot(daily["tx_date"], daily["cumulative_spend"], color="#2f6f73", linewidth=2)
    ax.set_title("Daily Cumulative Spend")
    ax.set_xlabel("Date")
    ax.set_ylabel("Cumulative Spend")
    ax.grid(True, alpha=0.3)

    return _save_chart(fig, "daily_trend.png")


def budget_vs_actual(df_budget):
    """Save a grouped bar chart of budget limit vs actual spend."""
    plot_df = df_budget.sort_values("category").reset_index(drop=True)
    positions = range(len(plot_df))
    width = 0.38

    fig, ax = plt.subplots(figsize=(10, 5))
    ax.bar(
        [pos - width / 2 for pos in positions],
        plot_df["limit_amount"],
        width=width,
        label="Budget Limit",
        color="#59a14f",
    )
    ax.bar(
        [pos + width / 2 for pos in positions],
        plot_df["actual_spend"],
        width=width,
        label="Actual Spend",
        color="#e15759",
    )
    ax.set_title("Budget vs Actual Spend")
    ax.set_xlabel("Category")
    ax.set_ylabel("Amount")
    ax.set_xticks(list(positions))
    ax.set_xticklabels(plot_df["category"], rotation=45, ha="right")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)

    return _save_chart(fig, "budget_vs_actual.png")
