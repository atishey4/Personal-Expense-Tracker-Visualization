from pathlib import Path
import sqlite3

import matplotlib.pyplot as plt
import pandas as pd
import streamlit as st

from src.analyze import fetch_frame, kpis, monthly_summary, category_summary
from src.budget import check_budget, set_budget
from src.categorize import RULES, classify, run as categorize_transactions
from src.ingest import read_bank_csv, upsert_transactions
from src.models import DB_PATH, PROJECT_ROOT, init_db


UPLOAD_DIR = PROJECT_ROOT / "data" / "uploads"
ACCOUNTS = ["Cash", "UPI", "Credit Card"]


def get_categories():
    init_db()
    with sqlite3.connect(DB_PATH) as conn:
        existing = [
            row[0]
            for row in conn.execute("SELECT name FROM categories ORDER BY name").fetchall()
        ]
    return sorted(set(existing) | set(RULES))


def ensure_category(category):
    init_db()
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("INSERT OR IGNORE INTO categories (name) VALUES (?)", (category,))
        return conn.execute(
            "SELECT id FROM categories WHERE name = ?",
            (category,),
        ).fetchone()[0]


def insert_manual_transaction(tx_date, description, amount, account, category):
    category_id = ensure_category(category)
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("PRAGMA foreign_keys=ON")
        cursor = conn.execute(
            """
            INSERT OR IGNORE INTO transactions (
                tx_date, description, amount, account, category_id, raw_source
            )
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                tx_date.strftime("%Y-%m-%d"),
                description.strip(),
                float(amount),
                account,
                category_id,
                "manual_entry",
            ),
        )
        return cursor.rowcount


def money(value):
    return f"INR {value:,.2f}"


def filter_frame(df, month, account):
    filtered = df.copy()
    if month != "All":
        filtered = filtered[filtered["month"] == month]
    if account != "All":
        filtered = filtered[filtered["account"] == account]
    return filtered


def plot_monthly_trend(df):
    monthly = monthly_summary(df)
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.plot(monthly["month"], monthly["total_spend"], marker="o", linewidth=2)
    ax.set_xlabel("Month")
    ax.set_ylabel("Spend")
    ax.grid(True, alpha=0.25)
    ax.tick_params(axis="x", rotation=45)
    fig.tight_layout()
    return fig


def plot_category_bar(df, month):
    data = category_summary(df, month).sort_values("spend")
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.barh(data["category"], data["spend"], color="#4c78a8")
    ax.set_xlabel("Spend")
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    return fig


def plot_payment_pie(df, month):
    expenses = df[(df["amount"] < 0) & (df["month"] == month)].copy()
    expenses["spend"] = expenses["amount"].abs()
    data = expenses.groupby("account", as_index=False)["spend"].sum()

    fig, ax = plt.subplots(figsize=(5, 5))
    ax.pie(data["spend"], labels=data["account"], autopct="%1.1f%%", startangle=90)
    ax.axis("equal")
    fig.tight_layout()
    return fig


def highlight_over_budget(row):
    if row.get("over_budget", False):
        return ["background-color: #ffd6d6"] * len(row)
    return [""] * len(row)


def render_upload():
    with st.expander("Upload CSV", expanded=False):
        uploaded = st.file_uploader("CSV file", type=["csv"])
        if uploaded is None:
            return

        preview = pd.read_csv(uploaded)
        st.dataframe(preview.head(10), use_container_width=True)

        columns = preview.columns.tolist()
        with st.form("upload_form"):
            col1, col2 = st.columns(2)
            with col1:
                account = st.selectbox("Account", ACCOUNTS, key="upload_account")
                date_col = st.selectbox("Date column", columns)
            with col2:
                desc_col = st.selectbox("Description column", columns)
                amt_col = st.selectbox("Amount column", columns)

            submitted = st.form_submit_button("Ingest CSV")

        if submitted:
            UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
            upload_path = UPLOAD_DIR / uploaded.name
            upload_path.write_bytes(uploaded.getvalue())
            normalized = read_bank_csv(upload_path, account, date_col, desc_col, amt_col)
            inserted = upsert_transactions(normalized)
            categorized = categorize_transactions()
            st.success(f"Inserted {inserted} new transactions. Categorized {categorized}.")
            st.rerun()


def render_manual_entry(categories):
    with st.expander("Manual Expense Entry", expanded=False):
        with st.form("manual_entry_form"):
            col1, col2, col3 = st.columns(3)
            with col1:
                tx_date = st.date_input("Date")
                account = st.selectbox("Account", ACCOUNTS, key="manual_account")
            with col2:
                amount = st.number_input("Amount", value=-100.0, step=100.0)
                category = st.selectbox("Category", categories)
            with col3:
                description = st.text_input("Description")
                submitted = st.form_submit_button("Add Transaction")

        if submitted:
            if not description.strip():
                st.error("Description is required.")
                return
            inserted = insert_manual_transaction(
                tx_date, description, amount, account, category
            )
            if inserted:
                st.success("Transaction added.")
            else:
                st.warning("Duplicate transaction ignored.")
            st.rerun()


def render_budget_form(month, categories):
    with st.expander("Set Budget", expanded=False):
        with st.form("budget_form"):
            col1, col2, col3 = st.columns(3)
            with col1:
                budget_month = st.text_input("Month", value=month if month != "All" else "")
            with col2:
                category = st.selectbox("Budget category", categories)
            with col3:
                limit = st.number_input("Limit amount", min_value=0.0, step=500.0)
            submitted = st.form_submit_button("Save Budget")

        if submitted:
            if not budget_month:
                st.error("Month is required in YYYY-MM format.")
                return
            set_budget(budget_month, category, limit)
            st.success("Budget saved.")
            st.rerun()


def main():
    st.set_page_config(page_title="Personal Expense Tracker", layout="wide")
    init_db()
    categorize_transactions()

    st.title("Personal Expense Tracker")
    render_upload()

    categories = get_categories()
    render_manual_entry(categories)

    df = fetch_frame()
    if df.empty:
        st.info("No transactions available yet.")
        return

    months = ["All"] + sorted(df["month"].dropna().unique().tolist())
    accounts = ["All"] + sorted(df["account"].dropna().unique().tolist())

    with st.sidebar:
        selected_month = st.selectbox("Month", months, index=len(months) - 1)
        selected_account = st.selectbox("Account", accounts)

    render_budget_form(selected_month, categories)

    filtered = filter_frame(df, selected_month, selected_account)
    totals = kpis(filtered)

    metric_cols = st.columns(3)
    metric_cols[0].metric("Total Spend", money(totals["total_spend"]))
    metric_cols[1].metric("Income", money(totals["income"]))
    metric_cols[2].metric("Savings", money(totals["savings"]))

    if filtered.empty:
        st.info("No transactions match the selected filters.")
        return

    chart_month = (
        selected_month
        if selected_month != "All"
        else sorted(filtered["month"].dropna().unique().tolist())[-1]
    )

    left, right = st.columns(2)
    with left:
        st.subheader("Category Spend")
        st.pyplot(plot_category_bar(filtered, chart_month))
    with right:
        st.subheader("Monthly Trend")
        st.pyplot(plot_monthly_trend(filtered))

    left, right = st.columns(2)
    with left:
        st.subheader("Payment Method")
        st.pyplot(plot_payment_pie(filtered, chart_month))
    with right:
        st.subheader("Budget Check")
        budget_df = check_budget(chart_month)
        if budget_df.empty:
            st.info("No budgets set for this month.")
        else:
            st.dataframe(
                budget_df.style.apply(highlight_over_budget, axis=1),
                use_container_width=True,
                hide_index=True,
            )

    st.subheader("Transactions")
    st.dataframe(
        filtered.sort_values("tx_date", ascending=False),
        use_container_width=True,
        hide_index=True,
    )


if __name__ == "__main__":
    main()
