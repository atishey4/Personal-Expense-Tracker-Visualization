import sqlite3

import pandas as pd

from src.models import DB_PATH, init_db


def fetch_frame(db_path=DB_PATH):
    """Load transactions with category names into a DataFrame."""
    init_db(db_path)

    with sqlite3.connect(db_path) as conn:
        df = pd.read_sql_query(
            """
            SELECT
                t.id,
                t.tx_date,
                t.description,
                t.amount,
                t.currency,
                t.account,
                t.raw_source,
                t.tags,
                c.name AS category
            FROM transactions t
            LEFT JOIN categories c ON c.id = t.category_id
            ORDER BY t.tx_date, t.id
            """,
            conn,
            parse_dates=["tx_date"],
        )

    if not df.empty:
        df["month"] = df["tx_date"].dt.to_period("M").astype(str)
        df["category"] = df["category"].fillna("Uncategorized")

    return df


def kpis(df):
    """Return headline totals and top expense categories."""
    expenses = df[df["amount"] < 0].copy()
    income = df[df["amount"] > 0]["amount"].sum()
    total_spend = expenses["amount"].abs().sum()
    savings = income - total_spend

    top_categories = (
        expenses.assign(spend=expenses["amount"].abs())
        .groupby("category", as_index=False)["spend"]
        .sum()
        .sort_values("spend", ascending=False)
        .head(5)
        .reset_index(drop=True)
    )

    return {
        "total_spend": float(total_spend),
        "income": float(income),
        "savings": float(savings),
        "top_5_categories": top_categories,
    }


def monthly_summary(df):
    """Return month-wise expense totals."""
    expenses = df[df["amount"] < 0].copy()
    expenses["spend"] = expenses["amount"].abs()

    return (
        expenses.groupby("month", as_index=False)["spend"]
        .sum()
        .rename(columns={"spend": "total_spend"})
        .sort_values("month")
        .reset_index(drop=True)
    )


def category_summary(df, month):
    """Return category-wise expense split for a YYYY-MM month."""
    expenses = df[(df["amount"] < 0) & (df["month"] == month)].copy()
    expenses["spend"] = expenses["amount"].abs()

    return (
        expenses.groupby("category", as_index=False)["spend"]
        .sum()
        .sort_values("spend", ascending=False)
        .reset_index(drop=True)
    )


def daily_trend(df):
    """Return daily spending totals."""
    expenses = df[df["amount"] < 0].copy()
    expenses["spend"] = expenses["amount"].abs()

    return (
        expenses.groupby("tx_date", as_index=False)["spend"]
        .sum()
        .rename(columns={"tx_date": "date"})
        .sort_values("date")
        .reset_index(drop=True)
    )
