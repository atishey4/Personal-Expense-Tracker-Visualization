from pathlib import Path

import pandas as pd

from src.analyze import category_summary, fetch_frame
from src.budget import check_budget
from src.models import PROJECT_ROOT


REPORTS_DIR = PROJECT_ROOT / "reports"


def export_month(month):
    """Export a monthly Excel report with transactions, category summary, and budget check."""
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    output_path = REPORTS_DIR / f"expense_report_{month}.xlsx"

    df = fetch_frame()
    transactions = df[df["month"] == month].copy()
    transactions["tx_date"] = transactions["tx_date"].dt.strftime("%Y-%m-%d")

    category_pivot = category_summary(df, month).rename(
        columns={"category": "Category", "spend": "Total Spend"}
    )
    budget = check_budget(month).rename(
        columns={
            "category": "Category",
            "limit_amount": "Limit Amount",
            "actual_spend": "Actual Spend",
            "over_by": "Over By",
            "over_budget": "Over Budget",
        }
    )

    with pd.ExcelWriter(output_path, engine="xlsxwriter") as writer:
        transactions.to_excel(writer, sheet_name="Transactions", index=False)
        category_pivot.to_excel(writer, sheet_name="Category Summary", index=False)
        budget.to_excel(writer, sheet_name="Budget Check", index=False)

        workbook = writer.book
        money_format = workbook.add_format({"num_format": '#,##0.00'})
        date_format = workbook.add_format({"num_format": "yyyy-mm-dd"})

        for sheet_name, worksheet in writer.sheets.items():
            worksheet.freeze_panes(1, 0)
            worksheet.autofilter(0, 0, 0, max(0, worksheet.dim_colmax))
            worksheet.set_column(0, max(0, worksheet.dim_colmax), 18)

        transactions_sheet = writer.sheets["Transactions"]
        if "tx_date" in transactions.columns:
            tx_date_col = transactions.columns.get_loc("tx_date")
            transactions_sheet.set_column(tx_date_col, tx_date_col, 14, date_format)
        if "amount" in transactions.columns:
            amount_col = transactions.columns.get_loc("amount")
            transactions_sheet.set_column(amount_col, amount_col, 14, money_format)

        summary_sheet = writer.sheets["Category Summary"]
        if not category_pivot.empty:
            spend_col = category_pivot.columns.get_loc("Total Spend")
            summary_sheet.set_column(spend_col, spend_col, 14, money_format)

        budget_sheet = writer.sheets["Budget Check"]
        for column in ["Limit Amount", "Actual Spend", "Over By"]:
            if column in budget.columns:
                col_index = budget.columns.get_loc(column)
                budget_sheet.set_column(col_index, col_index, 14, money_format)

    return output_path


if __name__ == "__main__":
    print(export_month("2026-04"))
