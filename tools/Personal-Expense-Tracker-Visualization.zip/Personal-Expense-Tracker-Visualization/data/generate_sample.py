from pathlib import Path
import random

import pandas as pd


OUTPUT_PATH = Path(__file__).resolve().parent / "expenses_sample.csv"
RANDOM_SEED = 42

ACCOUNTS = ["Cash", "UPI", "Credit Card"]
CATEGORY_DESCRIPTIONS = {
    "Food & Dining": [
        "Restaurant dinner",
        "Cafe coffee",
        "Office lunch",
        "Food delivery",
        "Weekend brunch",
    ],
    "Transport": [
        "Metro recharge",
        "Cab ride",
        "Fuel refill",
        "Auto fare",
        "Parking fee",
    ],
    "Groceries": [
        "Supermarket groceries",
        "Fresh vegetables",
        "Monthly staples",
        "Dairy purchase",
        "Fruit market",
    ],
    "Shopping": [
        "Clothing purchase",
        "Online shopping",
        "Home essentials",
        "Electronics accessory",
        "Gift purchase",
    ],
    "Bills & Utilities": [
        "Electricity bill",
        "Internet bill",
        "Mobile recharge",
        "Water bill",
        "Gas cylinder",
    ],
    "Entertainment": [
        "Movie tickets",
        "Streaming subscription",
        "Concert booking",
        "Gaming purchase",
        "Weekend outing",
    ],
    "Income": [
        "Monthly salary",
        "Freelance payment",
        "Interest credit",
        "Cashback reward",
        "Reimbursement",
    ],
}

EXPENSE_RANGES = {
    "Food & Dining": (120, 2200),
    "Transport": (40, 1800),
    "Groceries": (250, 4500),
    "Shopping": (500, 9000),
    "Bills & Utilities": (300, 6000),
    "Entertainment": (150, 3500),
}
INCOME_RANGES = {
    "Monthly salary": (70000, 95000),
    "Freelance payment": (8000, 25000),
    "Interest credit": (300, 1200),
    "Cashback reward": (50, 600),
    "Reimbursement": (1000, 7000),
}


def random_amount(category, description):
    if category == "Income":
        low, high = INCOME_RANGES[description]
        return round(random.uniform(low, high), 2)

    low, high = EXPENSE_RANGES[category]
    return -round(random.uniform(low, high), 2)


def generate_sample():
    random.seed(RANDOM_SEED)
    rows = []

    for month in range(1, 7):
        month_start = pd.Timestamp(year=2025, month=month, day=1)
        month_end = month_start + pd.offsets.MonthEnd(0)

        rows.append(
            {
                "Date": month_start.strftime("%Y-%m-%d"),
                "Description": "Monthly salary - Income",
                "Amount": random_amount("Income", "Monthly salary"),
                "Account": "UPI",
            }
        )

        for category in EXPENSE_RANGES:
            for _ in range(4):
                tx_date = month_start + pd.Timedelta(
                    days=random.randint(0, month_end.day - 1)
                )
                description = random.choice(CATEGORY_DESCRIPTIONS[category])
                rows.append(
                    {
                        "Date": tx_date.strftime("%Y-%m-%d"),
                        "Description": f"{description} - {category}",
                        "Amount": random_amount(category, description),
                        "Account": random.choice(ACCOUNTS),
                    }
                )

        for _ in range(4):
            tx_date = month_start + pd.Timedelta(days=random.randint(0, month_end.day - 1))
            description = random.choice(CATEGORY_DESCRIPTIONS["Income"][1:])
            rows.append(
                {
                    "Date": tx_date.strftime("%Y-%m-%d"),
                    "Description": f"{description} - Income",
                    "Amount": random_amount("Income", description),
                    "Account": random.choice(ACCOUNTS),
                }
            )

    df = pd.DataFrame(rows).sort_values(["Date", "Description"]).reset_index(drop=True)
    df.to_csv(OUTPUT_PATH, index=False)
    return df


if __name__ == "__main__":
    sample = generate_sample()
    print(f"Saved {len(sample)} rows to {OUTPUT_PATH}")
